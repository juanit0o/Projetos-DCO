package pt.tooyummytogo.exception;

public class SessaoInvalidaException extends Exception {
	
	/**
	 * ERRO APARECE QUANDO O USERNAME OU A PASSWORD N�O EXISTEM
	 */

}
