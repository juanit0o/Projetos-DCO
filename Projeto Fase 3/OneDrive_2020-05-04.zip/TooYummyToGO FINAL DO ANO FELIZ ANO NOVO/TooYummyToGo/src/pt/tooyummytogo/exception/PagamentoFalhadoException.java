package pt.tooyummytogo.exception;

public class PagamentoFalhadoException extends Exception{

	/**
	 * ERRO APARECE QUANDO O PAGAMENTO FALHA (CARTAO INVALIDO)
	 */
	
}
